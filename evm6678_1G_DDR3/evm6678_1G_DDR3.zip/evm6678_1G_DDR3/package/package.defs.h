/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A44
 */

#ifndef evm6678_1G_DDR3__
#define evm6678_1G_DDR3__



#endif /* evm6678_1G_DDR3__ */ 
